// popup.js
(async () => {
  // Quan el DOM del popup està llest
  $(document).ready(async () => {
    try {
      // Obtenir la pestanya activa
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const tabId = tab.id;

      // Injectar i obtenir l'HTML complet de la pàgina
      const [{ result: htmlContent }] = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => document.documentElement.outerHTML
      });

      const parser = new DOMParser();
      const doc = parser.parseFromString(htmlContent, 'text/html');

      const tableData = [];
      const headersCount = {};
      const allHeaders = new Set();

      // Recollir totes les files de la taula
      const trElements = doc.querySelectorAll('tr[name="tblDadesOrgans"]');
      for (const tr of trElements) {
        const trId = tr.id;
        const rowData = {};
        const tdElements = tr.querySelectorAll('td');

        for (let i = 0; i < tdElements.length; i += 2) {
          const label = tdElements[i].textContent.trim();
          const value = tdElements[i + 1]?.textContent.trim() || '';
          if (label) {
            rowData[label] = value;
            headersCount[label] = (headersCount[label] || 0) + 1;
            if (headersCount[label] > 0 && !rowData["Data baixa:"]) {
              allHeaders.add(label);
            }
          }
        }

        if (Object.keys(rowData).length > 0 && !rowData["Data baixa:"]) {
          tableData.push(rowData);
          // Mostrar la fila en el DOM original
          await chrome.scripting.executeScript({
            target: { tabId },
            func: (id) => {
              const el = document.getElementById(id);
              if (el) el.style.display = '';
            },
            args: [trId]
          });
        }
      }

      // Trobar número d'inscripció i nom d'entitat
      const buscaTd = (text) => Array.from(doc.querySelectorAll('td'))
        .find(td => td.textContent.includes(text))?.nextElementSibling?.textContent.trim() || '';
      const numeroInscripcioText = buscaTd("Número d'Inscripció:");
      const nomEntitatText = buscaTd("Nom Oficial de l'Entitat:");

      // Data actual YYYYMMDD
      const d = new Date();
      const formattedDate = `${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}`;

      // Configurar DataTable
      if (tableData.length && allHeaders.size) {
        const columnsConfig = Array.from(allHeaders).map(h => ({ title: h.replace(':',''), data: h }));
        const rowsConfig = tableData.map(row =>
          Object.fromEntries(Array.from(allHeaders).map(h => [h, row[h] || '']))
        );

        $('#dataTable').DataTable({
          data: rowsConfig,
          columns: columnsConfig,
          buttons: [{
            extend: 'excel',
            text: 'Descarregar XLSX',
            filename: `${formattedDate}_${numeroInscripcioText}_${nomEntitatText}`,
            title: null
          }],
          dom: 'Bfrtip',
          lengthMenu: [[-1], ['Mostra tot']]
        });
      } else {
        console.error("No hi ha dades per mostrar.");
      }

    } catch (err) {
      console.error("Error en el popup:", err);
    }
  });
})();